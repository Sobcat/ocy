<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>404-您访问的资源不存在</title>
<link href="http://static.websiteonline.cn/website/script/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<!--404页面-开始-->
<div class="website-404">
	<div class="ri-t">
		<h1>404</h1>
	  <h2>很抱歉，您访问的资源不存在！</h2>
	  <span>Sorry, your requested resource does not exist!</span>
	    <br />
<p>可能的原因有: <br />
•   您访问的资源不存在<br />
	    <br />
	    如果您有任何意见或建议，请及时反馈给我们，谢谢您的配合！ </p>
	</div>

</div>

</body>
</html>
